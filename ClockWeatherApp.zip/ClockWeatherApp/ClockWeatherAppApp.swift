//
//  ClockWeatherAppApp.swift
//  ClockWeatherApp
//
//  Created by Mark Mayne on 6/16/25.
//

import SwiftUI

@main
struct ClockWeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
